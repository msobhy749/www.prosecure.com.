$(document).ready(function () {
  $(".dropdown").hover(
    function () {
      $(this).addClass("show").attr("aria-expanded", "true");
      $(this).find(".dropdown-menu").addClass("show");
    },
    function () {
      $(this).removeClass("show").attr("aria-expanded", "false");
      $(this).find(".dropdown-menu").removeClass("show");
    }
  );

  $(window).scroll(function () {
    if ($(window).width() > 991) {
      if ($(window).scrollTop() > 0) {
        $("header nav").addClass("active");
      } else {
        $("header nav").removeClass("active");
      }
    }
  });

  for (let i = 0; i < $(".news .one-news").length; i++) {
    let src = $(".news .one-news").eq(i).find(".img img").attr("src");
    $(".news .one-news")
      .eq(i)
      .find(".img")
      .css("backgroundImage", "url('" + src + "')");
  }

  if ($("body").hasClass("ar")) {
    $(".ar .hero-slider .owl-carousel").owlCarousel({
      loop: true,
      margin: 0,
      smartSpeed: 800,
      autoplay: true,
      rtl: true,
      responsive: {
        0: {
          items: 1,
        },
      },
    });
  } else {
    $(".hero-slider .owl-carousel").owlCarousel({
      loop: true,
      margin: 0,
      smartSpeed: 800,
      autoplay: true,
      responsive: {
        0: {
          items: 1,
        },
      },
    });
  }

  // for(let i = 0; i < $('.hero-slider .owl-item').length;i++){
  //     let src = $('.hero-slider .owl-item').eq(i).find('.img img').attr('src');
  //     $('.hero-slider .owl-item').eq(i).find('.img').css('backgroundImage', "url('" + src + "')");
  // }

  let introTitles = [
    "The best security services under one roof",
    "Falcon group specializes in cash in transit",
    "Facility and property management",
  ];

  for (let i in introTitles) {
    $(".hero-slider .owl-dots .owl-dot")
      .eq(i)
      .find("span")
      .text(introTitles[i]);
  }

  $(".companies-slider .owl-carousel").owlCarousel({
    loop: false,
    margin: 10,
    nav: true,
    dots: false,
    navText: [
      '<img src="images/home/companies/prev.png" />',
      '<img src="images/home/companies/next.png" />',
    ],
    smartSpeed: 800,
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 3,
      },
      1000: {
        items: 5,
      },
    },
  });

  if ($('body').hasClass('ar')) {
    $(".ar .clients-slider .owl-carousel").owlCarousel({
      loop: true,
      margin: 10,
      smartSpeed: 800,
      rtl: true,
      responsive: {
        0: {
          items: 2,
        },
        600: {
          items: 3,
        },
        1200: {
          items: 5,
        },
      },
    });
  }else {
    $(".clients-slider .owl-carousel").owlCarousel({
      loop: true,
      margin: 10,
      smartSpeed: 800,
      responsive: {
        0: {
          items: 2,
        },
        600: {
          items: 3,
        },
        1200: {
          items: 5,
        },
      },
    });
  }

  

  if ($("main").hasClass("aboutPage")) {
    var partnersSwiper = new Swiper(".partners_swiper", {
      slidesPerView: 5,
      spaceBetween: 20,
      loop: true,
      autoHeight: true,
      autoplay: {
        delay: 5000,
      },
      speed: 1000,
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      // Responsive breakpoints
      breakpoints: {
        // when window width is >= 320px
        320: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        // when window width is >= 480px
        576: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        // when window width is >= 640px
        768: {
          slidesPerView: 3,
          spaceBetween: 30,
        },
        // when window width is >= 640px
        992: {
          slidesPerView: 4,
          spaceBetween: 20,
        },
        // when window width is >= 640px
        1200: {
          slidesPerView: 5,
          spaceBetween: 10,
        },
      },
    });
  }
  // ____________ Valid Input ____________ //
  $(".cust_form_control").focus(function () {
    $(this).addClass("valid");
  });
  $(".cust_form_control").blur(function () {
    if ($(this).val()) {
      $(this).addClass("valid");
    } else {
      $(this).removeClass("valid");
    }
  });
  // ____________ Valid Input ____________ //

  // ____________ Custmize Popup ____________ //
  $("header .navbar .navbar-nav .nav-item .nav-link.search").click(function (
    e
  ) {
    e.preventDefault();
    e.stopPropagation();
    $(".popup.popup_search").fadeIn().addClass("flex");
    $("html, body").css({
      overflowY: "hidden",
    });
  });
  $(".popup_close").click(function (e) {
    e.preventDefault();
    e.stopPropagation();
    $(".popup").fadeOut();
    $("html, body").css({
      overflowY: "auto",
    });
  });
  $(".popup_box_content").click(function (e) {
    e.preventDefault();
    e.stopPropagation();
  });
  $(window).click(function (e) {
    $(".popup").fadeOut();
    $("html, body").css({
      overflowY: "auto",
    });
  });
  // ____________ Custmize Popup ____________ //

  // ____________ News Slider ____________ //
  if ($("main").hasClass("newsDetailsPage")) {
    var newsSwiper = new Swiper(".otherNews_swiper", {
      slidesPerView: 3,
      spaceBetween: 30,
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
      autoplay: {
        delay: 5000,
      },
      speed: 1000,
      // Responsive breakpoints
      breakpoints: {
        // when window width is >= 320px
        320: {
          slidesPerView: 1,
          spaceBetween: 10,
        },
        // when window width is >= 480px
        577: {
          slidesPerView: 2,
          spaceBetween: 20,
        },
        // when window width is >= 640px
        992: {
          slidesPerView: 3,
          spaceBetween: 30,
        },
      },
    });
  }
  // ____________ News Slider ____________ //

  // ____________ File Upload ____________ //
  readUrl = function (input) {
    if (input.files && input.files[0]) {
      let reader = new FileReader();
      reader.onload = (e) => {
        let imgData = e.target.result;
        let imgName = input.files[0].name;
        input.setAttribute("data-title", imgName);
        console.log(e.target.result);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };
  // ____________ File Upload ____________ //

  new WOW().init();
});
